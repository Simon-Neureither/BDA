import scala.collection.mutable.ListBuffer


case class TestInformation(numberOfFreeFields : Long, solveTime : Long, loadTime : Long, solved : Int, filename : String, board: Board, solveSteps : Int)
{
  
  override def toString : String = {
    "Free Fields:\t" + numberOfFreeFields + "\tBesetzte Felder:\t" + (81 - numberOfFreeFields) + "\tSolveTime:\t" + solveTime + "\tSolved:\t" + solved + "\tLoadTime:\t" + loadTime + "\tFile:\t" + filename + "\tSolveSteps:\t" + solveSteps;
  }
}


object Test {
  
  def solve(args : Array[String], n : Int) =
  {
        Solver.count = 1;
        
    val list = ListBuffer[TestInformation]();
    
    var solveTime = 0.0;
    var loadTime = 0.0
    var solved = 0;

    for (i <- 0 to n - 1)
    {
      val t = exec(args);
      solveTime += t.solveTime;
      loadTime += t.loadTime;
    }
    
    solveTime /= n;
    loadTime /= n;
    
    val t = exec(args);

    val solveSteps = Solver.count;
    
    TestInformation(t.numberOfFreeFields, solveTime.toInt, loadTime.toInt, t.solved, t.filename, null, solveSteps);
  }
  
  def main(args : Array[String])
  {
    
    
    {
      val arr = Array("-s", "--------------3-85--1-2-------5-7-----4---1---9-------5------73--2-1--------4---9");
   //   println(solve(arr, 1));
  //    println(exec(arr, 1).solveTime);
    }
    
    // Solve one before so classes are loaded...
    val arr = Array("-f", "sudokus/easy_1.txt");
    solve(arr,  1);
  
    val map = ListBuffer[TestInformation]();
    
    val runs = 100;
    
    {
      val arr = Array("-s", "2------3----5-8---1---------84-----5-5----1------2----------72--9-1-----7---3----");
      println(solve(arr,  runs));
    }
        
    for (i <- 1 to 5)
    {
      val arr = Array("-f", "sudokus/17/" + i);
      println(solve(arr,  runs));
    }
    
    for (i <- 1 to 5)
    {
      val arr = Array("-f", "sudokus/easy_" + i + ".txt");
      println(solve(arr,  runs));
    }
    for (i <- 1 to 5)
    {
      val arr = Array("-f", "sudokus/medium_" + i + ".txt");
      println(solve(arr,  runs));
    }
    for (i <- 1 to 5)
    {
      val arr = Array("-f", "sudokus/hard_" + i + ".txt");
      println(solve(arr,  runs));
    }
    for (i <- 1 to 5)
    {
      val arr = Array("-f", "sudokus/evil_" + i + ".txt");
      println(solve(arr,  runs));
    }
    {
      val arr = Array("-f", "sudokus/hardest.txt");
      println(solve(arr,  runs));
    }
    {
       val arr = Array("-s", "--------------3-85--1-2-------5-7-----4---1---9-------5------73--2-1--------4---9");
      println(solve(arr,  runs));
  //    println(exec(arr, 1).solveTime);
    }
    {
      val arr = Array("-s", "2------3----5-8---1---------84-----5-5----1------2----------72--9-1-----7---3----");
        println(solve(arr,  runs));
    }
  }

  def exec(args:Array[String], to_solve : Int = 1) : TestInformation = {  
    
    
    val program_start_time = System.currentTimeMillis();
    
    var board : Board = null;
    
    if (args.size >= 2)
    {
      if (args(0).equals("-s"))
        board = Board.FromString(args(1));
      else if (args(0).equals("-f"))
        board = Board.FromFile(args(1));
    }
    
    
    if (board != null)
    {
        val n = board.getNumberOfFreeFields
        
        val finished_loading_time = System.currentTimeMillis();

        Solver.count = 1;
        val solver = new Solver(board);
        val solved = solver.solve(to_solve);
        
        if (solved.size >= 1)
          board = solved(0);
        
        val finished_solving_time = System.currentTimeMillis();
        
        return TestInformation(n, finished_solving_time - finished_loading_time, finished_loading_time - program_start_time, solved.size, args(1), board, Solver.count);
    }
      
    return TestInformation(0, -1, -1, 0, "", board, 0);
  }  
}

